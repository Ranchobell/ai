/*implementation of reverse*/
start:-write('Enter The List: '),
read(L),
reverselist(L,R),
write('The Reversed List Is: '),
write(R).
reverselist([],[]).
reverselist([H],[H]).
reverselist([H|T],R):-reverselist(T,R1),conc(R1,[H],R).
conc([],L1,L1).
conc([H|T],L2,[H|L3]):-conc(T,L2,L3).
