/*implementation of sumlist*/
go12:-write('Enter the list: '),
read(L),
sumlist(L,S),
write('The Sum Of The List Is: '),
write(S).
sumlist([], 0).
sumlist([Head | Tail], Sum) :-
sumlist(Tail, TailSum),
Sum is Head + TailSum.
