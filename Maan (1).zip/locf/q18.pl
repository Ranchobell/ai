/*implementation of merge*/
go:- write('Enter a list: '), read(L1), nl,
write('Enter another list: '), read(L2), nl,
merge(L1,L2,L3),
write('The merged list is: '), write(L3).
merge([H1|T1], [H2|T2], [H1|T]):-
  H1 < H2, !,
  merge(T1, [H2|T2], T).
merge([H1|T1], [H2|T2], [H2|T]):-
  merge([H1|T1], T2, T), !.
merge(L1, [], L1):- !.
merge([], L2, L2).
