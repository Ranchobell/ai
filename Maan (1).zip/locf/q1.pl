%PROGRAM for calculating sum of two numbers
go:- write('Enter the first number'),nl,read(A),
write('Enter the second number'),nl,read(B),
sum(A,B,C),
write('The sum is'),nl,
write(C).
%statement for sum function
sum(X,Y,Z):-Z is X+Y.
