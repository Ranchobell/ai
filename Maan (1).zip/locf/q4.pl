%program to implement fib(N,T) where T is the Nth term of series
go3:-write('Enter the value of N:'),read(N),nl,
fib(N,T),
write('The Nth term is:'),nl,
write(T).
fib(1,0):-!.
fib(2,1):-!.
fib(3,1):-!.
fib(A,X):- M is A-1,N is A-2,fib(M,W),fib(N,L),X is W+L.

