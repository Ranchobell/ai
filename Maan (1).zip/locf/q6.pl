%program to implement power function
go5:-write('Enter the value of base:'),read(A),nl,
write('Enter the value of exponent:'),read(B),nl,
po(A,B,C),
write('Result is:'),nl,write(C).
po(_,0,1).
po(N,1,N).
po(N,E,R):- R is N**E.
