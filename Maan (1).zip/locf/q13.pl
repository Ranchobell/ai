/*implementation of nth element*/
go14:- write('Enter a list: '), read(L), nl,
write('Enter a position in the list: '), read(N), nl,
nth_element(N,L,X),
write('The '),write(N),write('th '),write('element in the list is: '),
write(X).
nth_element(1, [H|_], H):- !.
nth_element(N, [_|T], X):-
	N > 0,
	N1 is N - 1,
	nth_element(N1, T, X).
