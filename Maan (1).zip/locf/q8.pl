%program to implement member function(X,L)
go7:-write('Enter the value to be checked:'),read(X),nl,
write('Enter the list:'),read(L),
memb(X,L).
memb(X,[X|_]).
memb(X,[_|T]):-memb(X,T).

