%program for gcd of a two numbers
go4:- write('Enter First number:'),read(A),nl,
write('Enter second number:'),read(B),nl,
gcd(A,B,Result),
write('GCD of the two Numbers is:'),nl,write(Result).
gcd(A,0,A).
gcd(A,B,Result):- B>0,C is A mod B,gcd(B,C,Result).
