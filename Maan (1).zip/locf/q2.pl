%program to find maximum of two numbers
go1:-write('Enter the first number:'),read(X),nl,
write('Enter the second number:'),read(Y),nl,
max(X,Y,Z),
write('Maximum of the two numbers is:'),write(Z).
max(X,Y,Z):-X>=Y,
Z is X.
max(X,Y,Z):-X<Y,
Z is Y.
