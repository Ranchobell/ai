%program to implement multiplication
go6:-write('Enter first number:'),read(N1),nl,
write('Enter second number:'),read(N2),nl,
mul(N1,N2,C),
write('The Result is:'),nl,write(C).
mul(0,_,0).
mul(_,0,0).
mul(A,B,C):- C is A*B.
