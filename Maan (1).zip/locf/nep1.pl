write_move(N,X,Y) :-
  write('Move disk'),
  write(N),
  write(' from '),
  write(X),
  write(' to '),
  write(Y),nl.

move(1, X, Y, _) :-
    write_move(1,X,Y).

move(N, X, Y, Z) :-
  N > 1,
  M is N - 1,
  move(M, X, Z, Y),  % Move smaller disks to auxiliary rod
  write_move(N,X,Y),
  % Print move with disk number (using write/2)
  move(M, Z, Y, X).   % Move smaller disks to target rod using auxiliary rod

towers_of_hanoi(N, Source, Target, Aux) :-
  move(N, Source, Target, Aux).
