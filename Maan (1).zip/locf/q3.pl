%program for factorial of a number
go2:-write('Enter the Value of Number :'),read(A),nl,
fact(A,F),
write('Factorial is:'),write(F).
fact(0,1).
%general function
fact(N,F):-N>0,N1 is N-1,fact(N1,F1),F is N*F1.
